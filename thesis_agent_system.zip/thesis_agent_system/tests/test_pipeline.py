import pytest
from backend.pipeline import ThesisPipeline

@pytest.mark.asyncio
async def test_pipeline_runs():
    content = """
摘要
本文设计一种无人机异构双模信号侦测系统。
关键词：无人机；检测

第一章 研究背景
这个系统主要解决复杂环境下的问题。

参考文献
[1] 示例文献.
"""
    pipe = ThesisPipeline()
    resp = await pipe.run("测试论文", content)
    assert resp.score >= 0
    assert len(resp.agent_results) == 5
    assert resp.report_markdown.startswith("#")
