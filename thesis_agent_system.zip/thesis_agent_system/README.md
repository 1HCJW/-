# ThesisAgent：论文评审与改写多 Agent 系统

这是一个可直接运行、可二次扩展的「论文评审 + 降重改写 + 格式检查 + 引用检查 + 报告导出」示例项目。  
项目默认使用本地规则引擎与 Mock LLM，不需要 API Key 也能运行；如果配置 `OPENAI_API_KEY`，可切换为真实大模型调用。

## 功能亮点

- 论文文本上传与分析
- 多 Agent 协作流程
  - ReviewAgent：结构、摘要、关键词、章节完整性评审
  - RewriteAgent：学术化改写、降重表达、AIGC 痕迹控制
  - CitationAgent：参考文献与正文引用检查
  - FormatAgent：图表编号、标题层级、常见格式问题检查
  - RiskAgent：重复表达、口语化表达、逻辑跳跃风险提示
- 任务流水线编排
- Web 前端页面
- FastAPI 后端接口
- SQLite 历史记录
- Markdown / JSON 报告导出
- 可扩展 LLM Provider
- 命令行批处理工具
- Docker 一键部署

## 目录结构

```text
thesis_agent_system/
├── backend/
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── pipeline.py
│   ├── agents/
│   │   ├── base.py
│   │   ├── review_agent.py
│   │   ├── rewrite_agent.py
│   │   ├── citation_agent.py
│   │   ├── format_agent.py
│   │   └── risk_agent.py
│   ├── services/
│   │   ├── document_parser.py
│   │   ├── report_service.py
│   │   ├── text_utils.py
│   │   └── llm_provider.py
│   └── cli.py
├── frontend/
│   ├── index.html
│   ├── app.js
│   └── style.css
├── examples/
│   └── sample_thesis.txt
├── tests/
│   └── test_pipeline.py
├── requirements.txt
├── .env.example
├── Dockerfile
└── docker-compose.yml
```

## 快速开始

### 1. 安装依赖

```bash
cd thesis_agent_system
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

macOS / Linux：

```bash
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. 启动后端

```bash
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

### 3. 打开前端

浏览器打开：

```text
frontend/index.html
```

也可以直接访问后端文档：

```text
http://127.0.0.1:8000/docs
```

## 使用真实大模型

复制配置文件：

```bash
cp .env.example .env
```

填入：

```env
LLM_PROVIDER=openai
OPENAI_API_KEY=你的key
OPENAI_MODEL=gpt-4o-mini
```

未配置 Key 时，系统自动使用本地 Mock 模式，便于答辩展示。

## 命令行使用

```bash
python -m backend.cli examples/sample_thesis.txt --out report.md
```

## API 示例

### 分析文本

```bash
curl -X POST http://127.0.0.1:8000/api/analyze-text \
  -H "Content-Type: application/json" \
  -d "{\"title\":\"测试论文\",\"content\":\"这里放论文正文\"}"
```

### 上传文件分析

支持 `.txt` 和 `.md`，也可扩展 `.docx`。

```bash
curl -X POST http://127.0.0.1:8000/api/analyze-file \
  -F "file=@examples/sample_thesis.txt"
```

## 二次开发建议

你可以继续加入：
- Word 文档解析与批注回写
- 知网/维普/Turnitin 风格相似度接口
- 学校模板格式规则
- RAG 参考文献检索
- 多用户权限
- 队列任务 Celery / Redis
- PDF 报告导出
