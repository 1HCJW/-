import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass
class Settings:
    app_name: str = os.getenv("APP_NAME", "ThesisAgent")
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./thesis_agent.db")
    llm_provider: str = os.getenv("LLM_PROVIDER", "mock")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    max_rewrite_paragraphs: int = int(os.getenv("MAX_REWRITE_PARAGRAPHS", "8"))

settings = Settings()
