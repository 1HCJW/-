import re
from typing import List, Dict

CHINESE_PUNCT = "。！？；"

def split_paragraphs(text: str) -> List[str]:
    parts = [p.strip() for p in re.split(r"\n\s*\n|\r\n\s*\r\n", text) if p.strip()]
    if len(parts) <= 1:
        parts = [p.strip() for p in text.split("\n") if p.strip()]
    return parts

def count_chinese_chars(text: str) -> int:
    return len(re.findall(r"[\u4e00-\u9fff]", text))

def sentence_count(text: str) -> int:
    return max(1, len(re.findall(r"[。！？!?]", text)))

def extract_headings(text: str) -> List[str]:
    headings = []
    for line in text.splitlines():
        s = line.strip()
        if re.match(r"^第[一二三四五六七八九十]+章", s):
            headings.append(s)
        elif re.match(r"^\d+(\.\d+)*\s+.+", s):
            headings.append(s)
    return headings

def keyword_density(text: str, keywords: List[str]) -> Dict[str, int]:
    return {kw: text.count(kw) for kw in keywords}

def find_citations(text: str) -> List[str]:
    return re.findall(r"\[(\d+(?:[-,，]\d+)*)\]", text)

def find_references(text: str) -> List[str]:
    refs = []
    in_refs = False
    for line in text.splitlines():
        if "参考文献" in line:
            in_refs = True
            continue
        if in_refs and line.strip():
            refs.append(line.strip())
    return refs

def rough_similarity_risk(paragraph: str) -> float:
    repeated = len(re.findall(r"(研究|系统|检测|实现|分析|设计)", paragraph))
    length = max(1, count_chinese_chars(paragraph))
    return min(1.0, repeated / max(10, length / 20))

def academic_rewrite_rules(text: str) -> str:
    replacements = {
        "这个": "该",
        "很多": "较多",
        "非常": "较为",
        "然后": "随后",
        "可以": "能够",
        "所以": "因此",
        "就是": "即",
        "东西": "内容",
        "不好": "存在不足",
        "比较": "相对",
        "大概": "基本",
        "做了": "完成",
        "用了": "采用",
    }
    result = text
    for k, v in replacements.items():
        result = result.replace(k, v)
    result = re.sub(r"我(们)?", "本文", result)
    return result
