from pathlib import Path

class DocumentParser:
    """轻量文档解析器。默认支持 txt/md，后续可扩展 docx/pdf。"""

    @staticmethod
    def parse_bytes(filename: str, data: bytes) -> str:
        suffix = Path(filename).suffix.lower()
        if suffix in [".txt", ".md", ".csv"]:
            for enc in ["utf-8", "gbk", "gb18030"]:
                try:
                    return data.decode(enc)
                except UnicodeDecodeError:
                    pass
            return data.decode("utf-8", errors="ignore")
        raise ValueError(f"暂不支持 {suffix} 文件，请上传 .txt 或 .md")
