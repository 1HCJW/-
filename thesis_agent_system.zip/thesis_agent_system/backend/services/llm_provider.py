from abc import ABC, abstractmethod
from typing import Dict, Any
import httpx
from ..config import settings

class BaseLLMProvider(ABC):
    @abstractmethod
    async def complete(self, prompt: str, system: str = "") -> str:
        raise NotImplementedError

class MockLLMProvider(BaseLLMProvider):
    async def complete(self, prompt: str, system: str = "") -> str:
        return (
            "【Mock LLM 输出】已根据输入文本生成修改建议。"
            "当前为本地演示模式，如需真实大模型，请配置 OPENAI_API_KEY。"
        )

class OpenAICompatibleProvider(BaseLLMProvider):
    async def complete(self, prompt: str, system: str = "") -> str:
        if not settings.openai_api_key:
            return await MockLLMProvider().complete(prompt, system)

        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {settings.openai_api_key}",
            "Content-Type": "application/json",
        }
        payload: Dict[str, Any] = {
            "model": settings.openai_model,
            "messages": [
                {"role": "system", "content": system or "你是严谨的中文论文写作助手。"},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.3,
        }
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]

def get_llm_provider() -> BaseLLMProvider:
    if settings.llm_provider.lower() == "openai":
        return OpenAICompatibleProvider()
    return MockLLMProvider()
