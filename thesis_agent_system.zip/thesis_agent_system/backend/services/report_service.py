from datetime import datetime
from ..schemas import AnalysisResponse

class ReportService:
    @staticmethod
    def to_markdown(resp: AnalysisResponse) -> str:
        lines = []
        lines.append(f"# {resp.title}：论文智能评审报告")
        lines.append("")
        lines.append(f"- 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"- 综合得分：{resp.score}")
        lines.append(f"- 总结：{resp.summary}")
        lines.append("")
        lines.append("## 一、Agent 检查结果")
        for ar in resp.agent_results:
            lines.append(f"### {ar.agent}")
            lines.append(ar.summary)
            if ar.issues:
                for item in ar.issues:
                    lines.append(f"- **{item.level.upper()}｜{item.category}**：{item.message}")
                    lines.append(f"  - 建议：{item.suggestion}")
            else:
                lines.append("- 未发现明显问题。")
            lines.append("")
        lines.append("## 二、可替换改写文本")
        if resp.rewrites:
            for idx, item in enumerate(resp.rewrites, start=1):
                lines.append(f"### 改写 {idx}")
                lines.append("**原文：**")
                lines.append(item.original)
                lines.append("")
                lines.append("**建议改写：**")
                lines.append(item.rewritten)
                lines.append("")
                lines.append(f"**原因：** {item.reason}")
                lines.append("")
        else:
            lines.append("暂无需要改写的段落。")
        lines.append("## 三、修改优先级建议")
        lines.append("1. 先处理结构缺失、引用编号错误、参考文献缺失等硬性问题。")
        lines.append("2. 再处理图表编号、标题层级、连续空格等格式问题。")
        lines.append("3. 最后对重复表达、口语化表达和逻辑跳跃段落进行润色。")
        return "\n".join(lines)
