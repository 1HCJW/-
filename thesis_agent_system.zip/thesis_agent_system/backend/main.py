import json
from fastapi import FastAPI, UploadFile, File, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .database import Base, engine, get_db
from .models import AnalysisRecord
from .schemas import AnalyzeTextRequest, AnalysisResponse
from .pipeline import ThesisPipeline
from .services.document_parser import DocumentParser

Base.metadata.create_all(bind=engine)

app = FastAPI(title="ThesisAgent API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"name": "ThesisAgent", "message": "论文评审与改写多 Agent 系统运行中"}

@app.post("/api/analyze-text", response_model=AnalysisResponse)
async def analyze_text(req: AnalyzeTextRequest, db: Session = Depends(get_db)):
    pipeline = ThesisPipeline()
    resp = await pipeline.run(req.title, req.content)

    record = AnalysisRecord(
        title=req.title,
        content_preview=req.content[:500],
        report_json=resp.model_dump_json(ensure_ascii=False),
        report_markdown=resp.report_markdown,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    resp.id = record.id
    return resp

@app.post("/api/analyze-file", response_model=AnalysisResponse)
async def analyze_file(file: UploadFile = File(...), db: Session = Depends(get_db)):
    try:
        data = await file.read()
        content = DocumentParser.parse_bytes(file.filename, data)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    pipeline = ThesisPipeline()
    resp = await pipeline.run(file.filename, content)

    record = AnalysisRecord(
        title=file.filename,
        content_preview=content[:500],
        report_json=resp.model_dump_json(ensure_ascii=False),
        report_markdown=resp.report_markdown,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    resp.id = record.id
    return resp

@app.get("/api/history")
async def history(db: Session = Depends(get_db)):
    rows = db.query(AnalysisRecord).order_by(AnalysisRecord.id.desc()).limit(20).all()
    return [
        {
            "id": r.id,
            "title": r.title,
            "created_at": r.created_at.isoformat(),
            "preview": r.content_preview,
        }
        for r in rows
    ]

@app.get("/api/history/{record_id}")
async def get_record(record_id: int, db: Session = Depends(get_db)):
    row = db.query(AnalysisRecord).filter(AnalysisRecord.id == record_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="记录不存在")
    return {
        "id": row.id,
        "title": row.title,
        "created_at": row.created_at.isoformat(),
        "report": json.loads(row.report_json),
        "markdown": row.report_markdown,
    }

@app.get("/api/history/{record_id}/report.md")
async def get_markdown_report(record_id: int, db: Session = Depends(get_db)):
    row = db.query(AnalysisRecord).filter(AnalysisRecord.id == record_id).first()
    if not row:
        raise HTTPException(status_code=404, detail="记录不存在")
    return {"filename": f"report_{record_id}.md", "content": row.report_markdown}
