from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field

class AnalyzeTextRequest(BaseModel):
    title: str = Field(default="未命名论文")
    content: str = Field(min_length=20)

class Issue(BaseModel):
    level: str
    category: str
    message: str
    suggestion: str

class RewriteItem(BaseModel):
    original: str
    rewritten: str
    reason: str

class AgentResult(BaseModel):
    agent: str
    summary: str
    issues: List[Issue] = []
    data: Dict[str, Any] = {}

class AnalysisResponse(BaseModel):
    id: Optional[int] = None
    title: str
    score: float
    summary: str
    agent_results: List[AgentResult]
    rewrites: List[RewriteItem]
    report_markdown: str
