from typing import Dict, Any
from .base import BaseAgent
from ..schemas import AgentResult
from ..services.text_utils import split_paragraphs, rough_similarity_risk

class RiskAgent(BaseAgent):
    name = "RiskAgent"

    async def run(self, title: str, content: str, context: Dict[str, Any]) -> AgentResult:
        issues = []
        paragraphs = split_paragraphs(content)

        high_risk = []
        for i, p in enumerate(paragraphs, start=1):
            risk = rough_similarity_risk(p)
            if risk > 0.35 and len(p) > 80:
                high_risk.append((i, risk))

        for i, risk in high_risk[:5]:
            issues.append(self.issue(
                "warning", "表达风险",
                f"第 {i} 段重复表达风险偏高，估计值 {risk:.2f}。",
                "建议改写句式结构，减少高频词重复，并增加具体测试数据或工程分析。"
            ))

        if "本文主要" in content and content.count("本文主要") >= 4:
            issues.append(self.issue(
                "info", "AIGC 痕迹",
                "“本文主要”出现频率较高，容易造成模板化表达。",
                "建议改为更具体的主语和动作，例如“系统设计围绕……展开”。"
            ))

        return AgentResult(
            agent=self.name,
            summary=f"风险扫描完成，发现 {len(high_risk)} 个较高风险段落。",
            issues=issues,
            data={"high_risk_paragraphs": high_risk}
        )
