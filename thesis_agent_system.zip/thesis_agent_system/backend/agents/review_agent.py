from typing import Dict, Any
from .base import BaseAgent
from ..schemas import AgentResult
from ..services.text_utils import count_chinese_chars, extract_headings, keyword_density

class ReviewAgent(BaseAgent):
    name = "ReviewAgent"

    async def run(self, title: str, content: str, context: Dict[str, Any]) -> AgentResult:
        issues = []
        headings = extract_headings(content)
        char_count = count_chinese_chars(content)

        if char_count < 3000:
            issues.append(self.issue(
                "warning", "篇幅",
                f"当前中文字符约 {char_count}，整体篇幅偏短。",
                "建议补充研究背景、系统设计、测试分析与总结展望，使内容更完整。"
            ))

        required = ["摘要", "关键词", "研究背景", "系统设计", "测试", "总结", "参考文献"]
        density = keyword_density(content, required)
        for item, count in density.items():
            if count == 0:
                issues.append(self.issue(
                    "error", "结构完整性",
                    f"未检测到“{item}”相关内容。",
                    f"建议补充“{item}”部分，保证论文结构完整。"
                ))

        if len(headings) < 5:
            issues.append(self.issue(
                "warning", "章节层级",
                "检测到的章节标题数量较少，论文层次可能不够清晰。",
                "建议按章、节、小节组织内容，并保持标题编号连续。"
            ))

        score = max(55, 95 - len(issues) * 6)
        context["review_score"] = score
        context["headings"] = headings

        return AgentResult(
            agent=self.name,
            summary=f"结构评审完成，检测到 {len(issues)} 个问题，初步结构得分 {score}。",
            issues=issues,
            data={"char_count": char_count, "headings": headings, "structure_score": score}
        )
