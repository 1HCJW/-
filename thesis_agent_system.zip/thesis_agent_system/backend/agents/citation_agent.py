from typing import Dict, Any
from .base import BaseAgent
from ..schemas import AgentResult
from ..services.text_utils import find_citations, find_references

class CitationAgent(BaseAgent):
    name = "CitationAgent"

    async def run(self, title: str, content: str, context: Dict[str, Any]) -> AgentResult:
        issues = []
        citations = find_citations(content)
        refs = find_references(content)

        if len(refs) == 0:
            issues.append(self.issue(
                "error", "参考文献",
                "未检测到参考文献条目。",
                "建议在文末加入参考文献，并按 GB/T 7714 格式编排。"
            ))

        if len(citations) == 0:
            issues.append(self.issue(
                "warning", "正文引用",
                "正文中未检测到数字型引用标注。",
                "建议在引用资料、技术参数和关键观点处添加 [1]、[2] 等顺序编码引用。"
            ))

        if len(citations) > 0 and len(refs) > 0:
            max_cite = 0
            for c in citations:
                nums = c.replace("，", ",").replace("-", ",").split(",")
                for n in nums:
                    if n.isdigit():
                        max_cite = max(max_cite, int(n))
            if max_cite > len(refs):
                issues.append(self.issue(
                    "error", "引用编号",
                    f"正文最大引用编号为 [{max_cite}]，但参考文献只有 {len(refs)} 条。",
                    "请补齐参考文献，或调整正文引用编号。"
                ))

        return AgentResult(
            agent=self.name,
            summary=f"引用检查完成，正文引用 {len(citations)} 处，参考文献 {len(refs)} 条。",
            issues=issues,
            data={"citation_count": len(citations), "reference_count": len(refs)}
        )
