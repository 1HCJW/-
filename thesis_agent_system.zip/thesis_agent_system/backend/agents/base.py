from abc import ABC, abstractmethod
from typing import List, Dict, Any
from ..schemas import AgentResult, Issue

class BaseAgent(ABC):
    name = "BaseAgent"

    def issue(self, level: str, category: str, message: str, suggestion: str) -> Issue:
        return Issue(level=level, category=category, message=message, suggestion=suggestion)

    @abstractmethod
    async def run(self, title: str, content: str, context: Dict[str, Any]) -> AgentResult:
        raise NotImplementedError
