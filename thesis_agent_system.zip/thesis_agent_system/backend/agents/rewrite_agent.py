from typing import Dict, Any, List
from .base import BaseAgent
from ..schemas import AgentResult, RewriteItem
from ..services.text_utils import split_paragraphs, rough_similarity_risk, academic_rewrite_rules
from ..config import settings

class RewriteAgent(BaseAgent):
    name = "RewriteAgent"

    async def run(self, title: str, content: str, context: Dict[str, Any]) -> AgentResult:
        paragraphs = split_paragraphs(content)
        candidates = []
        for p in paragraphs:
            if len(p) >= 60:
                risk = rough_similarity_risk(p)
                if risk > 0.18 or any(w in p for w in ["这个", "很多", "然后", "就是", "比较"]):
                    candidates.append((p, risk))

        candidates = sorted(candidates, key=lambda x: x[1], reverse=True)[:settings.max_rewrite_paragraphs]
        rewrites: List[RewriteItem] = []
        for p, risk in candidates:
            rewritten = academic_rewrite_rules(p)
            if rewritten == p:
                rewritten = p.replace("系统", "本文所设计系统", 1)
            rewrites.append(RewriteItem(
                original=p,
                rewritten=rewritten,
                reason=f"该段存在表达重复或口语化风险，估计风险值 {risk:.2f}。"
            ))

        context["rewrites"] = [r.model_dump() for r in rewrites]

        issues = []
        if not rewrites:
            issues.append(self.issue(
                "info", "改写",
                "未发现明显需要改写的长段落。",
                "可结合导师意见进一步局部润色。"
            ))

        return AgentResult(
            agent=self.name,
            summary=f"改写筛选完成，共生成 {len(rewrites)} 条可替换文本。",
            issues=issues,
            data={"rewrites": [r.model_dump() for r in rewrites]}
        )
