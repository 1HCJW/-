from typing import Dict, Any
import re
from .base import BaseAgent
from ..schemas import AgentResult

class FormatAgent(BaseAgent):
    name = "FormatAgent"

    async def run(self, title: str, content: str, context: Dict[str, Any]) -> AgentResult:
        issues = []

        figure_nums = re.findall(r"图\s*(\d+(?:-\d+)?)", content)
        table_nums = re.findall(r"表\s*(\d+(?:-\d+)?)", content)

        if "图" in content and not figure_nums:
            issues.append(self.issue(
                "warning", "图编号",
                "文本中出现“图”，但未检测到规范图号。",
                "建议采用“图 2-1 系统总体结构框图”这类格式。"
            ))

        if "表" in content and not table_nums:
            issues.append(self.issue(
                "warning", "表编号",
                "文本中出现“表”，但未检测到规范表号。",
                "建议采用“表 4-1 测试结果统计表”这类格式。"
            ))

        if re.search(r"\[1\]\[2\]", content):
            issues.append(self.issue(
                "info", "引用格式",
                "检测到连续引用写法如 [1][2]。",
                "建议合并为 [1,2] 或 [1–2]，更符合常见顺序编码制写法。"
            ))

        if len(re.findall(r"\s{4,}", content)) > 5:
            issues.append(self.issue(
                "info", "空格",
                "检测到多处连续空格。",
                "建议统一清理多余空格，使版面更紧凑。"
            ))

        return AgentResult(
            agent=self.name,
            summary=f"格式检查完成，图号 {len(figure_nums)} 个，表号 {len(table_nums)} 个。",
            issues=issues,
            data={"figures": figure_nums, "tables": table_nums}
        )
