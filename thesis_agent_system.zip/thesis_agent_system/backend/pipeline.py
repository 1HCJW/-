from typing import Dict, Any, List
from .schemas import AnalysisResponse, AgentResult, RewriteItem
from .agents.review_agent import ReviewAgent
from .agents.rewrite_agent import RewriteAgent
from .agents.citation_agent import CitationAgent
from .agents.format_agent import FormatAgent
from .agents.risk_agent import RiskAgent
from .services.report_service import ReportService

class ThesisPipeline:
    def __init__(self):
        self.agents = [
            ReviewAgent(),
            CitationAgent(),
            FormatAgent(),
            RiskAgent(),
            RewriteAgent(),
        ]

    async def run(self, title: str, content: str) -> AnalysisResponse:
        context: Dict[str, Any] = {}
        results: List[AgentResult] = []

        for agent in self.agents:
            result = await agent.run(title, content, context)
            results.append(result)

        issues_count = sum(len(r.issues) for r in results)
        base_score = context.get("review_score", 85)
        score = max(0, min(100, base_score - issues_count * 1.8))

        rewrites = []
        for r in results:
            if r.agent == "RewriteAgent":
                rewrites = [RewriteItem(**item) for item in r.data.get("rewrites", [])]

        summary = (
            f"本次分析共调用 {len(self.agents)} 个 Agent，发现 {issues_count} 条问题或提示，"
            f"综合得分 {score:.1f}。建议优先处理 error 与 warning 级别问题。"
        )

        response = AnalysisResponse(
            title=title,
            score=round(score, 1),
            summary=summary,
            agent_results=results,
            rewrites=rewrites,
            report_markdown="",
        )
        response.report_markdown = ReportService.to_markdown(response)
        return response
