import argparse
import asyncio
from pathlib import Path
from .pipeline import ThesisPipeline

async def main():
    parser = argparse.ArgumentParser(description="ThesisAgent 命令行论文分析工具")
    parser.add_argument("file", help="论文文本文件路径，支持 txt/md")
    parser.add_argument("--out", default="report.md", help="输出 Markdown 报告路径")
    args = parser.parse_args()

    path = Path(args.file)
    content = path.read_text(encoding="utf-8")
    pipeline = ThesisPipeline()
    resp = await pipeline.run(path.name, content)

    Path(args.out).write_text(resp.report_markdown, encoding="utf-8")
    print(f"分析完成，得分：{resp.score}")
    print(f"报告已保存：{args.out}")

if __name__ == "__main__":
    asyncio.run(main())
