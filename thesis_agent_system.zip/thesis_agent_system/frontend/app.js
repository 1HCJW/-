const API = "http://127.0.0.1:8000";

const el = (id) => document.getElementById(id);

function setLoading(flag) {
  el("loading").classList.toggle("hidden", !flag);
}

function renderResult(data) {
  const issues = data.agent_results.flatMap(r =>
    r.issues.map(i => ({...i, agent: r.agent}))
  );

  el("result").innerHTML = `
    <div class="score">${data.score}</div>
    <p>${data.summary}</p>
    <h3>Agent 执行结果</h3>
    ${data.agent_results.map(r => `
      <div class="issue info">
        <b>${r.agent}</b><br/>
        ${r.summary}
      </div>
    `).join("")}
    <h3>问题清单</h3>
    ${issues.length ? issues.map(i => `
      <div class="issue ${i.level}">
        <b>${i.level.toUpperCase()}｜${i.category}</b><br/>
        ${i.message}<br/>
        <span class="muted">建议：${i.suggestion}</span>
      </div>
    `).join("") : "<p>未发现明显问题。</p>"}
    <h3>改写建议</h3>
    ${data.rewrites.length ? data.rewrites.map((r, idx) => `
      <div class="issue">
        <b>改写 ${idx + 1}</b>
        <p><b>原文：</b>${r.original}</p>
        <p><b>建议：</b>${r.rewritten}</p>
        <p class="muted">${r.reason}</p>
      </div>
    `).join("") : "<p>暂无改写建议。</p>"}
  `;
  el("report").textContent = data.report_markdown;
}

async function analyzeText() {
  const title = el("title").value.trim() || "未命名论文";
  const content = el("content").value.trim();
  if (content.length < 20) {
    alert("请至少输入 20 个字符");
    return;
  }

  setLoading(true);
  try {
    const resp = await fetch(`${API}/api/analyze-text`, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({title, content})
    });
    if (!resp.ok) throw new Error(await resp.text());
    renderResult(await resp.json());
  } catch (err) {
    el("result").innerHTML = `<div class="issue error">请求失败：${err.message}</div>`;
  } finally {
    setLoading(false);
  }
}

async function analyzeFile(file) {
  const form = new FormData();
  form.append("file", file);
  setLoading(true);
  try {
    const resp = await fetch(`${API}/api/analyze-file`, {
      method: "POST",
      body: form
    });
    if (!resp.ok) throw new Error(await resp.text());
    renderResult(await resp.json());
  } catch (err) {
    el("result").innerHTML = `<div class="issue error">上传失败：${err.message}</div>`;
  } finally {
    setLoading(false);
  }
}

async function loadHistory() {
  try {
    const resp = await fetch(`${API}/api/history`);
    if (!resp.ok) throw new Error(await resp.text());
    const rows = await resp.json();
    el("result").innerHTML = `
      <h3>最近分析记录</h3>
      ${rows.map(r => `
        <div class="issue info">
          <b>#${r.id} ${r.title}</b><br/>
          <span class="muted">${r.created_at}</span>
          <p>${r.preview}</p>
        </div>
      `).join("")}
    `;
  } catch (err) {
    el("result").innerHTML = `<div class="issue error">历史记录读取失败：${err.message}</div>`;
  }
}

el("analyzeBtn").addEventListener("click", analyzeText);
el("historyBtn").addEventListener("click", loadHistory);
el("fileInput").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (file) analyzeFile(file);
});

el("content").value = `摘要
随着低空无人机应用快速增长，传统单一模式检测方法在复杂无线环境下容易产生误报和漏报。本文设计一种无人机异构双模信号侦测系统，采用物理层射频能量检测与协议层无线帧监听相结合的方式，提高目标发现可靠性。
关键词：无人机；异构检测；STM32；ESP32；射频能量检测

第一章 研究背景
这个系统主要解决复杂环境下无人机信号不容易准确发现的问题。系统用了 AD8317、STM32、ESP32 和上位机等模块，然后通过串口进行数据传输。

第二章 系统设计
系统主要由物理层检测模块、协议层检测模块、主控模块、报警模块和上位机模块组成。物理层检测模块用于采集射频能量变化，协议层检测模块用于监听无线管理帧。

第三章 测试分析
测试结果表明，系统可以完成信号监测、状态显示和报警提示。但在连续运行过程中，还是会出现一些状态更新不够平滑的问题。

参考文献
[1] 罗俊海, 王芝燕. 无人机探测与对抗技术发展及应用综述[J]. 控制与决策, 2022.`;
